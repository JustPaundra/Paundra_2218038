/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 62821
 */
public class Data_kuliah {
    String nama_mk , dosen_pengampu ,kode_mk;
    int jml_sks,kode;
   
    public Data_kuliah(){
        this.kode_mk = "IF2112";
        this.nama_mk = "OOP";
        this.dosen_pengampu = "YOSEP AGUS PRANOTO, ST.MT.";
        this.jml_sks = 3;
    }
}
